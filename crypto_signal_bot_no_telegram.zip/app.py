from flask import Flask, render_template, request, redirect, session
import requests
import talib
import numpy as np

app = Flask(__name__)
app.secret_key = 'your-secret-key'

# --- SIGNAL ENGINE ---
def get_price(symbol="BTCUSDT"):
    url = f"https://api.binance.com/api/v3/klines?symbol={symbol}&interval=1m&limit=100"
    data = requests.get(url).json()
    close_prices = [float(candle[4]) for candle in data]
    return close_prices

def generate_signal(prices):
    prices_np = np.array(prices)

    # RSI
    rsi = talib.RSI(prices_np, timeperiod=14)
    latest_rsi = rsi[-1]

    # MACD
    macd, signal, hist = talib.MACD(prices_np, fastperiod=12, slowperiod=26, signalperiod=9)
    latest_macd = macd[-1]
    latest_signal = signal[-1]

    if latest_rsi < 30 and latest_macd > latest_signal:
        return "BUY"
    elif latest_rsi > 70 and latest_macd < latest_signal:
        return "SELL"
    else:
        return "HOLD"

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = request.form['username']
        pwd = request.form['password']
        if user == 'admin' and pwd == 'pass123':
            session['user'] = user
            return redirect('/dashboard')
        else:
            return render_template('login.html', error="Invalid credentials")
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect('/')
    prices = get_price()
    signal = generate_signal(prices)
    return render_template('index.html', signal=signal)

@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect('/')